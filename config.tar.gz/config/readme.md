Throw these onto /home/username/.config

thats all now go